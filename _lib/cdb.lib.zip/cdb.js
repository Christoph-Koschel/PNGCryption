class Bundler {
    modules;
    loaded;
    name;
    constructor(name) {
        this.modules = new Map();
        this.loaded = new Map();
        this.name = name;
    }
    register(id, requires, module) {
        this.modules.set(id, {
            config: {},
            imports: requires,
            module: module
        });
    }
    load(...items) {
        for (let i = 0; i < items.length; i++) {
            const [status] = this.loadItem(items[i]);
            if (!status) {
                return;
            }
        }
    }
    loadItem(item) {
        if (!this.modules.has(item)) {
            let domain = item.split("_")[0];
            if (typeof window == "undefined") {
                if (typeof global["domain"] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                if (global["domain"][domain] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                else {
                    return global["domain"][domain].loadItem(item);
                }
            }
            else {
                if (typeof window["domain"] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                if (window["domain"][domain] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                else {
                    return window["domain"][domain].loadItem(item);
                }
            }
        }
        if (this.loaded.has(item)) {
            return [true, this.loaded.get(item)];
        }
        const module = this.modules.get(item);
        let imports = {};
        let exports = {};
        exports[item] = {};
        let config = {
            pragma: "once"
        };
        module.imports.forEach(subitem => {
            const [status, exports] = this.loadItem(subitem);
            if (!status) {
                console.error(`BUNDLER: Could not load reference '${subitem}' in ${item}`);
                return;
            }
            imports[subitem] = exports[subitem];
        });
        module.module(imports, exports, config);
        if (config.pragma == "once") {
            this.loaded.set(item, exports);
        }
        return [true, exports];
    }
}
const bundler = new Bundler("cdb");
if (typeof window == "undefined") {
    if (typeof global["domain"] == "undefined") {
        global["domain"] = {};
    }
    global["domain"]["cdb"] = bundler;
}
else {
    if (typeof window["domain"] == "undefined") {
        window["domain"] = {};
    }
    window["domain"]["cdb"] = bundler;
}
bundler.register("cdb_immutable_0", [], (imports, exports, config) => {
    {
        ImmutableArray.prototype.constructor = function (arr) {
            arr.forEach((item, index) => {
                this[index] = item;
            });
            Object.freeze(this);
        };
        Array.prototype.toImmutable = function () {
            return new ImmutableArray(this);
        };
        export {};
    }
});
bundler.register("cdb_linq_1", [], (imports, exports, config) => {
    {
        Array.prototype.select = function (cb) {
            const result = [];
            this.forEach((item, index) => {
                result.push(cb(item, index));
            });
            return result;
        };
        Array.prototype.where = function (cb) {
            const result = [];
            this.forEach((item, index) => {
                if (cb(item, index)) {
                    result.push(item);
                }
            });
            return result;
        };
        Array.prototype.until = function (cb) {
            const result = [];
            let index = 0;
            for (const item of this) {
                if (!cb(item, index++)) {
                    break;
                }
                result.push(item);
            }
            return result;
        };
        Array.prototype.all = function (cb, smart = true) {
            let ok = true;
            let index = 0;
            for (const item of this) {
                if (!cb(item, index++)) {
                    ok = false;
                    if (!smart) {
                        break;
                    }
                }
            }
            return ok;
        };
        Array.prototype.any = function (cb, smart = true) {
            if (!cb) {
                return this.length != 0;
            }
            let ok = false;
            let index = 0;
            for (const item of this) {
                if (cb(item, index++)) {
                    ok = true;
                    if (smart) {
                        break;
                    }
                }
            }
            return ok;
        };
        Array.prototype.count = function (cb) {
            let counter = 0;
            this.forEach((item, index) => {
                counter += cb(item, index);
            });
            return counter;
        };
        Array.prototype.first = function (cb) {
            let index = 0;
            for (const item of this) {
                if (cb(item, index++)) {
                    return item;
                }
            }
            return null;
        };
        Array.prototype.last = function (cb) {
            let last = null;
            this.forEach((item, index) => {
                if (cb(item, index)) {
                    last = item;
                }
            });
            return last;
        };
        Array.prototype.chunk = function (size) {
            const result = [];
            let buff = [];
            for (let i = 0, k = 0; i < this.length; i++, k++) {
                if (k >= size) {
                    k = 0;
                    result.push(buff);
                    buff = [];
                }
                buff.push(this[i]);
            }
            return result;
        };
        export {};
    }
});
bundler.register("cdb_memorizable_2", [], (imports, exports, config) => {
    {
        class MemorizableCache {
            func;
            cases;
            constructor(func) {
                this.func = func;
                this.cases = new Map();
            }
        }
        class Memorizable {
            static boxes = [];
            static check(cb, ...parameters) {
                const box = this.boxes.first((box) => box.func == cb);
                if (box.cases.has(parameters)) {
                    return box.cases.get(parameters);
                }
                let value = cb(...parameters);
                box.cases.set(parameters, value);
                return value;
            }
        }
        function get_temperatures(destionation) {
            return Memorizable.check(() => {
                return [];
            }, destionation);
        }
        exports["cdb_memorizable_2"].Memorizable = Memorizable;
    }
});
bundler.register("cdb_object_3", [], (imports, exports, config) => {
    {
        Object.prototype.clone = function () {
            let obj = {};
            Object.keys(this).forEach((key) => {
                if (typeof this[key] == "object") {
                    obj[key] = this[key].clone();
                }
                else {
                    obj[key] = this[key];
                }
            });
            return obj;
        };
        export {};
    }
});
bundler.register("cdb_promisify_4", [], (imports, exports, config) => {
    {
        async function promisfy(fun) {
            return new Promise((resolve) => {
            });
        }
        exports["cdb_promisify_4"].promisfy = promisfy;
    }
});
