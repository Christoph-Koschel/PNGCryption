export declare function promisfy<T extends Function>(fun: T): Promise<keyof (T)>;
