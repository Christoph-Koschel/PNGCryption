export declare class Memorizable {
    private static boxes;
    static check<T>(cb: Function, ...parameters: any[]): T;
}
