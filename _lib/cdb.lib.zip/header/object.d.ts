declare global {
    interface Object {
        clone(): any;
    }
}
export {};
