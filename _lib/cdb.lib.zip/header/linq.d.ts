type BasicCallback<T> = {
    (item: T, index: number): boolean;
};
type SelectCallback<T, R> = {
    (item: T, index: number): R;
};
type WhereCallback<T> = BasicCallback<T>;
type UntilCallback<T> = BasicCallback<T>;
type AllCallback<T> = BasicCallback<T>;
type AnyCallback<T> = BasicCallback<T>;
type CountCallback<T> = BasicCallback<T>;
type FirstCallback<T> = BasicCallback<T>;
type LastCallback<T> = BasicCallback<T>;
declare global {
    interface Array<T> {
        select<R>(cb: SelectCallback<T, R>): R[];
        where(cb: WhereCallback<T>): T[];
        until(cb: UntilCallback<T>): T[];
        all(cb: AllCallback<T>, smart?: boolean): boolean;
        any(cb?: AnyCallback<T>, smart?: boolean): boolean;
        count(cb: CountCallback<T>): number;
        first(cb: FirstCallback<T>): T;
        last(cb: LastCallback<T>): T;
        chunk(size: number): T[][];
    }
}
export {};
