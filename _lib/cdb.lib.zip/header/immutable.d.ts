declare global {
    class ImmutableArray<T> {
        readonly [index: number]: T;
        constructor(arr: T[]);
    }
    interface Array<T> {
        toImmutable(): ImmutableArray<T>;
    }
}
export {};
